<?php
$clave = $_POST['clave'];


// Webservice y parámetros
$webservice = "https://www.dafi.com.mx/ConsultaRemota/Service.asmx?wsdl";
$parametros = array('claveFideicomiso' => $clave);


// Consumir el servicio web

    $WS = new SoapClient($webservice, $parametros);
    $res = $WS->ObtenerRegion($parametros);
    $resultado = $res->ObtenerRegionResult;

//var_dump($resultado);

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Consulta de Regiones</title>
  <link rel="stylesheet" href="Styles.css"> </head>
<body>
  <h1>Consulta de las Regiones</h1>

  <table>
    <caption></caption>
    <tr><th>Zona</th><th>Nombre</th></tr>

    <?php
    foreach ($resultado->{'Region'} as $item){
      echo '<tr><td>'.$item->{'Zona'}.'</td><td>'.$item->{'Nombre'}.'</td></tr>';
    }
    ?>

  </table>
</body>
</html>